package com.vogel.hrpayroll;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HrPayrollApplicationTests {

	@Test
	void contextLoads() {
	}

}
